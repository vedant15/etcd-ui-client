# etcd-ui-client
This is a basic UI client for ETCD V3 . The client is based on electron (https://electron.atom.io/).

# Building the app
If you are on a Mac, you can just download the pre-built package from builds directory, for others please follow the steps below
1) Clone the repo
2) `npm install`
3) `npm install -g electron-packager`
4) run `electron-packager .`

